from pyngrok import ngrok

# Set your authtoken
ngrok.set_auth_token("2yfzR4uNgzARgqZIXbi7joK2RlI_UmeAjEUye1xwU2Xvbhpn")

# Open a tunnel on the default streamlit port 8501
public_url = ngrok.connect(8501)
print("Streamlit app URL:", public_url)
