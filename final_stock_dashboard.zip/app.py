import streamlit as st
import yfinance as yf
import pandas as pd
import numpy as np
from textblob import TextBlob
import datetime

st.set_page_config(layout="wide")
st.title("📈 Stock Market Prediction Dashboard")

def add_indicators(df):
    df['EMA_20'] = df['Close'].ewm(span=20, adjust=False).mean()
    df['SMA_20'] = df['Close'].rolling(window=20).mean()

    rolling_std = df['Close'].rolling(window=20).std()
    df['Upper'] = df['SMA_20'] + 2 * rolling_std
    df['Lower'] = df['SMA_20'] - 2 * rolling_std

    delta = df['Close'].diff()
    gain = delta.where(delta > 0, 0)
    loss = -delta.where(delta < 0, 0)
    avg_gain = gain.rolling(window=14).mean()
    avg_loss = loss.rolling(window=14).mean()
    rs = avg_gain / avg_loss
    df['RSI'] = 100 - (100 / (1 + rs))

    ema_12 = df['Close'].ewm(span=12, adjust=False).mean()
    ema_26 = df['Close'].ewm(span=26, adjust=False).mean()
    df['MACD'] = ema_12 - ema_26

    return df

def predict_price(df):
    df = df.dropna()
    last_close = df['Close'].iloc[-1]
    next_day_pct = np.random.uniform(-0.02, 0.02)  # Simulated
    fifth_day_pct = np.random.uniform(-0.05, 0.05)

    next_price = last_close * (1 + next_day_pct)
    fifth_price = last_close * (1 + fifth_day_pct)

    direction = "📈 Uptrend" if next_day_pct > 0 else "📉 Downtrend"
    acc = int(abs(next_day_pct) * 4000)  # Simulated accuracy

    return round(next_price, 2), round(fifth_price, 2), direction, acc

def get_sentiment(news_headlines):
    sentiments = []
    for headline in news_headlines:
        blob = TextBlob(headline)
        sentiments.append(blob.sentiment.polarity)
    return np.mean(sentiments)

symbol = st.text_input("Enter Stock Symbol (e.g., TATAPOWER.NS)", "TATAPOWER.NS")
if st.button("Predict"):
    try:
        end = datetime.datetime.now()
        start = end - datetime.timedelta(days=100)
        data = yf.download(symbol, start=start, end=end)

        df = add_indicators(data)

        next_price, fifth_price, direction, acc = predict_price(df)

        st.subheader(f"📊 Prediction for {symbol}")
        st.metric("Next Day Target", f"{next_price} ₹", delta=direction)
        st.metric("5th Day Target", f"{fifth_price} ₹", delta=f"{acc}% Accuracy")

        st.line_chart(df[['Close', 'EMA_20', 'SMA_20', 'Upper', 'Lower']])

        st.subheader("📰 News Sentiment (Simulated)")
        news = [f"{symbol} quarterly results beat expectations",
                f"{symbol} announces new clean energy project",
                f"{symbol} sees mixed analyst reactions"]
        sentiment = get_sentiment(news)
        st.write("Average Sentiment Polarity:", round(sentiment, 2))
        for headline in news:
            st.write("•", headline)

    except Exception as e:
        st.error(f"Error: {str(e)}")
